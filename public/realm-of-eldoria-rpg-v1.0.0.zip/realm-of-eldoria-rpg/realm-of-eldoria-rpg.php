<?php
/**
 * Plugin Name: Realm of Eldoria 3D RPG
 * Plugin URI: https://wordpress.org/plugins/realm-of-eldoria-rpg/
 * Description: Täysiverinen 3D-roolipeli WordPress-sivustoille. Sisältää avoimen maailman, luokat (Velho, Haltija, Soturi, Kääpiö, Hobitti), torjunnan, loitsut ja kaivostoiminnan.
 * Version: 1.0.0
 * Author: Eldoria Studio
 * Author URI: https://eldoria.rpg
 * License: MIT
 * License URI: https://opensource.org/licenses/MIT
 * Text Domain: realm-of-eldoria-rpg
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('ELDORIA_RPG_VERSION', '1.0.0');
define('ELDORIA_RPG_PATH', plugin_dir_path(__FILE__));
define('ELDORIA_RPG_URL', plugin_dir_url(__FILE__));

/**
 * Upottaa 3D-roolipelin sivuille lyhytkoodilla: [eldoria_rpg]
 * Esimerkkejä:
 * [eldoria_rpg]
 * [eldoria_rpg width="100%" height="800px" fullscreen="yes"]
 */
function eldoria_rpg_shortcode_handler($atts) {
    $atts = shortcode_atts(array(
        'width' => get_option('eldoria_width', '100%'),
        'height' => get_option('eldoria_height', '720px'),
        'fullscreen' => get_option('eldoria_fullscreen', 'yes'),
        'class' => get_option('eldoria_default_class', 'warrior'),
    ), $atts, 'eldoria_rpg');

    $iframe_url = ELDORIA_RPG_URL . 'game/index.html?class=' . esc_attr($atts['class']);
    $container_id = 'eldoria-rpg-' . uniqid();

    ob_start();
    ?>
    <div id="<?php echo esc_attr($container_id); ?>" class="eldoria-rpg-container" style="position:relative; width:<?php echo esc_attr($atts['width']); ?>; max-width:1400px; margin:24px auto; background:#080a0f; border-radius:14px; box-shadow:0 25px 50px -12px rgba(0, 0, 0, 0.7); border:2px solid #b45309; overflow:hidden;">
        <iframe 
            src="<?php echo esc_url($iframe_url); ?>" 
            style="width:100%; height:<?php echo esc_attr($atts['height']); ?>; border:none; display:block;"
            allow="fullscreen; autoplay" 
            loading="lazy"
            title="Realm of Eldoria 3D RPG">
        </iframe>
        <?php if ($atts['fullscreen'] === 'yes') : ?>
            <div style="position:absolute; bottom:16px; right:16px; z-index:30;">
                <button 
                    type="button"
                    onclick="var el=document.getElementById('<?php echo esc_js($container_id); ?>'); if(el.requestFullscreen){el.requestFullscreen();}else if(el.webkitRequestFullscreen){el.webkitRequestFullscreen();}" 
                    style="background:#d97706; color:#0f172a; border:none; padding:8px 16px; font-weight:700; border-radius:8px; cursor:pointer; font-family:sans-serif; font-size:12px; box-shadow:0 4px 6px rgba(0,0,0,0.4); display:flex; align-items:center; gap:6px;">
                    ⛶ Avaa koko ruudulle (Full Screen)
                </button>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('eldoria_rpg', 'eldoria_rpg_shortcode_handler');

/**
 * WordPress-hallintavalikko (WP-Admin Menu)
 */
function eldoria_rpg_add_admin_menu() {
    add_menu_page(
        'Realm of Eldoria 3D RPG',
        'Eldoria 3D RPG',
        'manage_options',
        'eldoria-rpg-settings',
        'eldoria_rpg_render_settings_page',
        'dashicons-games',
        68
    );
}
add_action('admin_menu', 'eldoria_rpg_add_admin_menu');

/**
 * Asetussivun renderöinti WP-Adminissa
 */
function eldoria_rpg_render_settings_page() {
    if (isset($_POST['eldoria_submit']) && check_admin_referer('eldoria_save_options')) {
        update_option('eldoria_width', sanitize_text_field($_POST['eldoria_width']));
        update_option('eldoria_height', sanitize_text_field($_POST['eldoria_height']));
        update_option('eldoria_fullscreen', sanitize_text_field($_POST['eldoria_fullscreen']));
        update_option('eldoria_default_class', sanitize_text_field($_POST['eldoria_default_class']));
        echo '<div class="notice notice-success is-dismissible"><p><strong>Asetukset tallennettu onnistuneesti!</strong></p></div>';
    }

    $width = get_option('eldoria_width', '100%');
    $height = get_option('eldoria_height', '720px');
    $fullscreen = get_option('eldoria_fullscreen', 'yes');
    $default_class = get_option('eldoria_default_class', 'warrior');
    ?>
    <div class="wrap">
        <h1>⚔️ Realm of Eldoria 3D RPG - Asetukset & Ohjeet</h1>
        <p>Voit upottaa 3D-roolipelin mihin tahansa artikkeliin, sivulle tai widgettiin lyhytkoodilla: <code style="font-size:15px; font-weight:bold; color:#b45309;">[eldoria_rpg]</code></p>
        
        <div style="background:#fff; padding:20px; border-left:4px solid #d97706; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
            <h2 style="margin-top:0;">🎮 Pika-asennusohje:</h2>
            <ol>
                <li>Luo tai muokkaa mitä tahansa sivua (esim. <em>Pelaa 3D RPG:tä</em>).</li>
                <li>Lisää <strong>Lyhytkoodi (Shortcode)</strong> -lohko ja kirjoita siihen: <code>[eldoria_rpg]</code></li>
                <li>Julkaise sivu ja nauti pelistä suoraan WordPressissä!</li>
            </ol>
        </div>

        <form method="post" action="">
            <?php wp_nonce_field('eldoria_save_options'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="eldoria_width">Peli-ikkunan oletusleveys</label></th>
                    <td>
                        <input name="eldoria_width" type="text" id="eldoria_width" value="<?php echo esc_attr($width); ?>" class="regular-text" placeholder="100% tai 1200px" />
                        <p class="description">Esim. <code>100%</code>, <code>1200px</code> tai <code>90vw</code>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="eldoria_height">Peli-ikkunan oletuskorkeus</label></th>
                    <td>
                        <input name="eldoria_height" type="text" id="eldoria_height" value="<?php echo esc_attr($height); ?>" class="regular-text" placeholder="720px" />
                        <p class="description">Esim. <code>720px</code> tai <code>85vh</code>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="eldoria_fullscreen">Koko ruudun (Full Screen) painike</label></th>
                    <td>
                        <select name="eldoria_fullscreen" id="eldoria_fullscreen">
                            <option value="yes" <?php selected($fullscreen, 'yes'); ?>>Kyllä (Näytä 'Avaa koko ruudulle' -painike)</option>
                            <option value="no" <?php selected($fullscreen, 'no'); ?>>Ei (Piilota painike)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="eldoria_default_class">Oletushahmoluokka</label></th>
                    <td>
                        <select name="eldoria_default_class" id="eldoria_default_class">
                            <option value="warrior" <?php selected($default_class, 'warrior'); ?>>Soturi (Warrior) - Raskas panssari & Torjuntamekaniikka</option>
                            <option value="wizard" <?php selected($default_class, 'wizard'); ?>>Velho (Wizard) - Tuliloitsu & Jäänova</option>
                            <option value="elf" <?php selected($default_class, 'elf'); ?>>Haltija (Elf) - Ketteryys & Nopeat iskut</option>
                            <option value="dwarf" <?php selected($default_class, 'dwarf'); ?>>Kääpiö (Dwarf) - Kaivostaidot & Takomisbonus</option>
                            <option value="hobbit" <?php selected($default_class, 'hobbit'); ?>>Hobitti (Hobbit) - Hiiviskely & Kauppa</option>
                        </select>
                        <p class="description">Pelaajat voivat vaihtaa hahmoluokkaa vapaasti myös pelin sisällä.</p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="eldoria_submit" id="submit" class="button button-primary" value="Tallenna asetukset" />
            </p>
        </form>
    </div>
    <?php
}
