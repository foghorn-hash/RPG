<?php
/**
 * Suoritetaan automaattisesti kun lisäosa poistetaan WordPressistä.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('eldoria_width');
delete_option('eldoria_height');
delete_option('eldoria_fullscreen');
delete_option('eldoria_default_class');
