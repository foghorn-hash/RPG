=== Realm of Eldoria 3D RPG ===
Contributors: Eldoria Studio
Tags: 3d game, rpg, threejs, roleplaying, open world, gaming, parry, spells, dwarf, hobbit
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.0.0
License: MIT
License URI: https://opensource.org/licenses/MIT

Täysiverinen 3D-roolipeli WordPress-sivustoille. Sisältää avoimen maailman, 5 hahmoluokkaa, torjuntamekaniikan, loitsut, kaivostoiminnan ja tehtävät.

== Kuvaus ==
Täysiverinen 3D-roolipeli WordPress-sivustoille. Sisältää avoimen maailman, luokat (Velho, Haltija, Soturi, Kääpiö, Hobitti), torjunnan, loitsut ja kaivostoiminnan.

Ominaisuudet:
* 5 hahmoluokkaa: Soturi (parry-torjunta), Velho (tulipallo & jäänova), Haltija (ketteryys & syöksy), Kääpiö (2x kaivosnopeus & takomisbonus), Hobitti (hiiviskely & 3.5x selkäänpuukotus).
* Avoin 3D-maailma: Sunfall Outpost, Whispering Forest, The Deep Grotto (maanalainen luolasto ja Mithril-suonet) ja muinaiset Runic Ruins.
* Täysi Three.js PBR-grafiikka ja syntetisoitu Web Audio -äänimaailma.
* Yksinkertainen upotus yhdellä lyhytkoodilla: [eldoria_rpg]
* Ei vaadi ulkoisia riippuvuuksia tai erillisiä pelipalvelimia.

== Asennus ==
1. Lataa `realm-of-eldoria-rpg.zip` omalle koneellesi.
2. Kirjaudu WordPress-sivustosi hallintapaneeliin (WP-Admin).
3. Siirry kohtaan: **Lisäosat -> Lisää uusi (Plugins -> Add New)**.
4. Klikkaa yläreunasta: **Lataa lisäosa (Upload Plugin)**.
5. Valitse `realm-of-eldoria-rpg.zip` -tiedosto ja klikkaa **Asenna nyt (Install Now)**.
6. Klikkaa **Ota lisäosa käyttöön (Activate Plugin)**.
7. Lisää lyhytkoodi `[eldoria_rpg]` mille tahansa sivulle tai julkaisuun!

== Lyhytkoodin parametrit ==
* `[eldoria_rpg]` (oletusasetukset)
* `[eldoria_rpg width="100%" height="800px"]`
* `[eldoria_rpg class="wizard"]` (aloitusluokkana Velho)
* `[eldoria_rpg fullscreen="yes"]`

== Usein kysytyt kysymykset ==
= Toimiiko tämä millä tahansa WordPress-palvelimella? =
Kyllä! Peli pyörii 100% selaimessa WebGL- ja Three.js -tekniikoilla. Palvelimelta ei vaadita Node.js:ää tai erikoispalveluja.

= Toimiiko mobiililaitteilla ja tabletilla? =
Kyllä, peli tukee kosketus- ja hiiriohjausta sekä skaalautuu responsiivisesti.

== Muutosloki ==
= 1.0.0 =
* Ensimmäinen virallinen julkaisu.
